package com.quizV1.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.quizV1.model.QuizCategory;



public interface QuizCategoryRepository extends CrudRepository<QuizCategory, Integer>{
	
	@Query(
			value="SELECT * FROM quiz_category t WHERE t.quiz_category_id = :searchTerm",
		    nativeQuery=true
		    )
	List<QuizCategory> findByQuiz_category_id(@Param("searchTerm") Integer id); 
}
