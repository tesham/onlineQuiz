package com.quizV1.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.quizV1.model.Answer;

public interface AnswerRepository extends CrudRepository<Answer, Integer> {
	
	@Query(
			value="SELECT * FROM answers t WHERE t.question_id = :searchTerm",
		    nativeQuery=true
		    )
	List<Answer> findAnswersByQuestionID(@Param("searchTerm") Integer question_id);
	
	
	@Query(
			value="SELECT * FROM answers t WHERE t.question_id = :searchTerm and t.is_true=1",
		    nativeQuery=true
		    )
	List<Answer> findCorrectAnswerByQuestionID(@Param("searchTerm") Integer question_id);
	
}
