package com.quizV1.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.quizV1.model.QuizTopic;


public interface QuizTopicRepository  extends CrudRepository<QuizTopic, Integer>{
	
	@Query(
	value="SELECT * FROM quiz_topic t WHERE t.quiz_category_id = :searchTerm",
    nativeQuery=true
    )
	List<QuizTopic> findByQuiz_category_id(@Param("searchTerm") Integer mail);
	
	@Query(
			value="SELECT * FROM quiz_topic t WHERE t.topic_id = :searchTerm",
		    nativeQuery=true
		    )
	Optional<QuizTopic> findById(@Param("searchTerm") Integer mail);
}
