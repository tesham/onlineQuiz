package com.quizV1.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.quizV1.model.Role;
import com.quizV1.model.User;

public interface RoleRepository extends CrudRepository<Role, Integer> {
	// Role findByRole(String role);
	//Role findByName(String role);
}
