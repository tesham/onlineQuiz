package com.quizV1.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.quizV1.model.Question;

public interface QuestionRepository extends CrudRepository<Question, Integer>{
	@Query(
			value="SELECT * FROM quistion t WHERE t.topic_id = :searchTerm",
		    nativeQuery=true
		    )
			List<Question> findQuestionsByTopic(@Param("searchTerm") Integer topic);
}
