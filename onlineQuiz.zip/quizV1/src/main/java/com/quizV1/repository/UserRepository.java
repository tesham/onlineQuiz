package com.quizV1.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.quizV1.model.User;

public interface UserRepository extends JpaRepository<User, Integer>{
	Optional<User> findByName(String name);
//	User findByUserName(String name);
//	@Query(
//			value="SELECT * FROM user t WHERE t.email = :searchTerm",
//            nativeQuery=true
//            )
//    public  Optional<User> findByMail(@Param("searchTerm") String mail);
	public  Optional<User> findByEmail( String mail);
	
	
}
