package com.quizV1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
//import org.springframework.security.authentication.encoding.PasswordEncoder;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.quizV1.repository.UserRepository;
import com.quizV1.service.AppUserDetailService;
import com.quizV1.service.QuizServiceImp;

@EnableGlobalMethodSecurity(prePostEnabled=true)
@EnableWebSecurity
@EnableJpaRepositories(basePackages="com.quizV1.repository")
@Configuration
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

	@Autowired
	AppUserDetailService userDetailService;
//	@Autowired
//	BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth)  throws Exception{
		auth.userDetailsService(userDetailService)
		.passwordEncoder(getPasswordEncoder());
		//.passwordEncoder(bCryptPasswordEncoder);
	}
    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
    	httpSecurity.csrf().disable();
    	httpSecurity.authorizeRequests().antMatchers("**/home/**").authenticated()
    	.anyRequest().permitAll()
    	.and()
    	.formLogin().loginPage("/login")
    	.defaultSuccessUrl("/home")
    	.and()
    	.logout();
}
    
    private PasswordEncoder getPasswordEncoder() {
    	return new PasswordEncoder() {
			
			@Override
			public boolean matches(CharSequence rawPassword, String encodedPassword) {
				// TODO Auto-generated method stub
				if(rawPassword.toString().equals(encodedPassword)) {
					return true;
				}else {
					return false;
				}
				
			}
			
			@Override
			public String encode(CharSequence rawPassword) {
				// TODO Auto-generated method stub
				return rawPassword.toString();
			}
		};
		}
    
    }


