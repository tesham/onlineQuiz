package com.quizV1.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.quizV1.helper.QuestionsAndAnswers;
import com.quizV1.model.Answer;
import com.quizV1.model.Question;
import com.quizV1.model.QuizCategory;
import com.quizV1.model.QuizTopic;
import com.quizV1.service.QuizServiceImp;

@RestController
@PreAuthorize("hasAnyRole('USER')")
@RequestMapping("/home")
public class HomeController {
	
	@Autowired
	QuizServiceImp quizService;
	
	@GetMapping("")
	public ModelAndView home(HttpServletRequest request,
            HttpServletResponse response)
	{
		ModelAndView model=new ModelAndView("home");
		//List<QuizCategory> qc=quizService.findAll();
		//request.getSession().setAttribute("quizCategory", qc);
		//model.addObject("quizCategory", qc);
		List<Answer> qc=quizService.findAnswerByQuestion_id(1);
		int len=qc.size();
		return model;
	}
	
	@GetMapping("/category")
	public ModelAndView getCategoryList(@RequestParam("id") int qcID) {
		ModelAndView model=new ModelAndView("categoryList");
		List<QuizTopic> quizTopic=quizService.findAllTopic(qcID);
		QuizCategory quizCategory=quizService.findQuizCategory(qcID);
		if(quizCategory!=null) {
			model.addObject("quizName", quizCategory.getQuiz_category_name());
		}
		if(quizTopic.isEmpty()) {
			model.addObject("noTopic", "No list is Added for this Category , Please Add it to Database");
		}else {
			model.addObject("quizTopic", quizTopic);
		}
		model.addObject("qcID", qcID);
		return model;
	}
	
	@GetMapping("/questions")
	public ModelAndView getQuestionsList(@RequestParam("id") int topic_id) {
		ModelAndView model=new ModelAndView("question");
		List<Question> questions=quizService.findQuestionsByTopic(topic_id);
		
		if(questions.isEmpty()) {
			model.addObject("noQuestion", "No questions available");
		}else {
//			HashMap<Integer, String> quesAndAnswers=new HashMap<Integer, String>();
//			for(int i=0;i<questions.size();i++) {
//				Answer answer=quizService.findCorrectAnswerByQuestionID(questions.get(i).getQuestion_id());
//				if(answer!=null) {
//					quesAndAnswers.put(questions.get(i).getQuestion_id(), answer.getAnswer());
//				}
//				
//			}
			
			//HashMap<Integer, QuestionsAndAnswers> quesAndAnswers=new HashMap<Integer, QuestionsAndAnswers>();
			List<QuestionsAndAnswers> quesAndAnswers=new ArrayList<QuestionsAndAnswers>();
			for(int i=0;i<questions.size();i++) {
				QuestionsAndAnswers ob=new QuestionsAndAnswers();
				ob.setQuestionNO(i+1);
				ob.setQuestion(questions.get(i).getQuestion());
				ob.setAnswers(quizService.getAnswersOfQuestion(questions.get(i).getQuestion_id()));
				ob.setCorrectAnswer(quizService.findCorrectAnswerByQuestionID(questions.get(i).getQuestion_id()).getAnswer());
				quesAndAnswers.add(ob);
			}
			//Gson gson = new Gson();
			//model.addObject("correctAnswers", gson.toJson(quesAndAnswers));
			model.addObject("correctAnswers", quesAndAnswers);
			model.addObject("questions", questions);
		}
		model.addObject("qcID", topic_id);
		return model;
	}
	
	
}
