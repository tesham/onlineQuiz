package com.quizV1.controller;

import java.sql.SQLException;
import java.util.Optional;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.quizV1.model.User;
import com.quizV1.model.UserDetailsImp;
import com.quizV1.repository.UserRepository;
import com.quizV1.service.AppUserDetailService;
import com.quizV1.service.UserServiceImp;

@Controller
//@RequestMapping("")
public class LoginController {
	
	@Autowired
	private DataSource dataSource;
//
//   @Autowired
//    private UserService userService;
	@Autowired
	UserServiceImp userlService;
	
	@RequestMapping(value= {"/", "/login"}, method=RequestMethod.GET)
	public ModelAndView hello() throws Exception {
		//ModelAndView model=new ModelAndView("login");
//		if(dataSource.getConnection()!=null) {
//			model.addObject("db", "database connected");
//		}
		return new ModelAndView("login");
	}
	@GetMapping("/register")
	public ModelAndView register() {
		return new ModelAndView("register");
	}
	@PostMapping("/register")
	public ModelAndView doRegister(
			@RequestParam("name") String name,
			@RequestParam("email") String email,
			@RequestParam("pass") String pass,
			@RequestParam("re_pass") String re_pass
			) {
		
		ModelAndView model=new ModelAndView("register");
		if(name.isEmpty()) {
			model.addObject("nameError", "Please Enter a User Name");
			return model;
		}else if(email.isEmpty()) {
			model.addObject("mailError", "Please Enter Email");
			return model;
		}else if(pass.isEmpty()) {
			model.addObject("passError", "Please Enter a Password");
			return model;
		}else if(re_pass.isEmpty()) {
			model.addObject("rePassError", "Please  Repeated  Password");
			return model;
		}else {
			//User ifUserPresent=userService.findUserByEmail(name);
			if(!pass.equals(re_pass)) {
				model.addObject("passMatchError", "Password Dont Match");
				return model;
			}else if(userlService.getUser(name)) {
				model.addObject("nameDBError", "User name Already exist");
				return model;
			}else if(userlService.findByMail(email)) {
				model.addObject("mailDBError", "Mail Already exist");
				return model;
		    }
			else {
				User user=new User();
				user.setName(name);
				user.setEmail(email);
				user.setPassword(pass);
				userlService.saveUser(user);
				return new ModelAndView("login","success","Successfully registered,Please log in to continue");
			}
		}
		//return null;
	}
	
}
