package com.quizV1.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.quizV1.model.Answer;
import com.quizV1.model.Question;
import com.quizV1.model.QuizCategory;
import com.quizV1.model.QuizTopic;
import com.quizV1.repository.AnswerRepository;
import com.quizV1.repository.QuestionRepository;
import com.quizV1.repository.QuizCategoryRepository;
import com.quizV1.repository.QuizTopicRepository;
import com.quizV1.service.QuizServiceImp;

@RestController
@PreAuthorize("hasAnyRole('ADMIN')")
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	QuizServiceImp quizService;
	@Autowired
	QuizCategoryRepository quizCategoryRepository;
	@Autowired
	QuizTopicRepository  quizTopicRepository;
	@Autowired
	QuestionRepository questionRepository;
	@Autowired 
	AnswerRepository answerRepository;
	
	@GetMapping("")
	public ModelAndView admin() {
		return new ModelAndView("admin");
	}
	
	@GetMapping("/category")
	public ModelAndView getCategory() {
		ModelAndView model=new ModelAndView("category");
		List<QuizCategory> qclist=quizService.findAll(); 
		model.addObject("categoryList",qclist);
		return model;
	}
	@PostMapping("/addCategory")
	public ModelAndView addCategory(@RequestParam("category") String category) {
		if(category.isEmpty()) {
			return new ModelAndView("category");
		}else {
			QuizCategory qc=new QuizCategory();
			qc.setQuiz_category_name(category);
			quizCategoryRepository.save(qc);
			return new ModelAndView("redirect:category");
		}
	}
	@GetMapping("/topiclist")
	//@RequestMapping(value = "topiclist/{id}")
	public ModelAndView topicList(@RequestParam("id") int qcID) {
		ModelAndView model=new ModelAndView("topicList");
		List<QuizTopic> quizTopic=quizService.findAllTopic(qcID);
		QuizCategory quizCategory=quizService.findQuizCategory(qcID);
		if(quizCategory!=null) {
			model.addObject("quiz", quizCategory);
		}
		if(quizTopic.isEmpty()) {
			model.addObject("noTopic", "No list is Added for this Category , Please Add it to Database");
		}else {
			model.addObject("quizTopic", quizTopic);
		}
		model.addObject("qcID", qcID);
		return model;
	}
	
	@PostMapping("/addTopic")
	public ModelAndView addTopic(
			@RequestParam("catId") String topicID,
			@RequestParam("topic") String topic,
			RedirectAttributes redirectAttributes
			) {
		if(topicID.isEmpty()) {
			return new ModelAndView("topicList");
		}else {
			redirectAttributes.addAttribute("id", Integer.parseInt(topicID));
			QuizTopic newTopic=new QuizTopic();
			newTopic.setTopic(topic);
			newTopic.setQuizCategory(Integer.parseInt(topicID));
			quizTopicRepository.save(newTopic);
			///id="+Integer.parseInt(topicID)
			return new ModelAndView("redirect:topiclist");
		}
	}
	
	@GetMapping("/questions")
	//@RequestMapping(value = "topiclist/{id}")
	public ModelAndView questionList(@RequestParam("id") int topicID) {
		ModelAndView model=new ModelAndView("addQuestion");
		QuizTopic quizTopic=quizTopicRepository.findById(topicID).get();
		if(quizTopic!=null) {
			model.addObject("quizTopic", quizTopic);
			model.addObject("topicID", topicID);
		}
		return model;
	}
	
	@PostMapping("/addQuestion")
	public ModelAndView addQuestion(
			@RequestParam("topicId") String topicID,
			@RequestParam("question") String question,
			@RequestParam("answer1") String answer1,
			@RequestParam("answer2") String answer2,
			@RequestParam("answer3") String answer3,
			@RequestParam("answer4") String answer4,
			@RequestParam("correct") String correct
			) {
		Question questionDB=new Question();
		questionDB.setTopic_id(Integer.parseInt(topicID));
		questionDB.setQuestion(question);
		questionRepository.save(questionDB);
		
		Answer ans1=new Answer();
		ans1.setAnswer(answer1);
		ans1.setQuestion_id(questionDB.getQuestion_id());
		if(correct.equals("1")) {
			ans1.setIs_true(1);
		}else {
			ans1.setIs_true(0);
		}
		
		Answer ans2=new Answer();
		ans2.setAnswer(answer2);
		ans2.setQuestion_id(questionDB.getQuestion_id());
		if(correct.equals("2")) {
			ans2.setIs_true(1);
		}else {
			ans2.setIs_true(0);
		}
		
		Answer ans3=new Answer();
		ans3.setAnswer(answer3);
		ans3.setQuestion_id(questionDB.getQuestion_id());
		if(correct.equals("3")) {
			ans3.setIs_true(1);
		}else {
			ans3.setIs_true(0);
		}
		
		Answer ans4=new Answer();
		ans4.setAnswer(answer4);
		ans4.setQuestion_id(questionDB.getQuestion_id());
		if(correct.equals("4")) {
			ans4.setIs_true(1);
		}else {
			ans4.setIs_true(0);
		}
		
		answerRepository.save(ans1);
		answerRepository.save(ans2);
		answerRepository.save(ans3);
		answerRepository.save(ans4);
		
		ModelAndView model=new ModelAndView("addQuestion");
		model.addObject("success", "Added Succesfully");
		return model;
	}
	
}
