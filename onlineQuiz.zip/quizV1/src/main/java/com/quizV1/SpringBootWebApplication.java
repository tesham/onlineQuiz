package com.quizV1;




import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.quizV1.service.QuizServiceImp;

//import com.quizV1.service.UserServiceImp;
@EnableAutoConfiguration
@SpringBootApplication
public class SpringBootWebApplication {
	

	
	

	public static void main(String[] args) throws Exception {
		SpringApplication.run(SpringBootWebApplication.class, args);
	}
	

	@Bean
	 public BCryptPasswordEncoder passwordEncoder() {
		  BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
		  return bCryptPasswordEncoder;
	 }

	

}
