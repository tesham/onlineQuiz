package com.quizV1.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quizV1.model.Answer;
import com.quizV1.model.Question;
import com.quizV1.model.QuizCategory;
import com.quizV1.model.QuizTopic;
import com.quizV1.repository.AnswerRepository;
import com.quizV1.repository.QuestionRepository;
import com.quizV1.repository.QuizCategoryRepository;
import com.quizV1.repository.QuizTopicRepository;

@Service
public class QuizServiceImp implements QuizService {
	
	@Autowired
	QuizCategoryRepository quizCategoryRepository;
	
	@Autowired
	QuizTopicRepository quizTopicRepository;
	
	@Autowired
	QuestionRepository questionRepository;
	
	@Autowired
	AnswerRepository answerRepository;

	@Override
	public List<QuizCategory> findAll() {
		List<QuizCategory> list = new ArrayList();
		list=(List<QuizCategory>)quizCategoryRepository.findAll();
		return list;
	}
	

	@Override
	public List<QuizTopic> findAllTopic(Integer id) {
		List<QuizTopic> list=quizTopicRepository.findByQuiz_category_id(id);
		return list;
	}


	@Override
	public List<Question> findQuestionsByTopic(Integer topic_id) {
		List<Question> qList=questionRepository.findQuestionsByTopic(topic_id);
		return qList;
	}


	@Override
	public List<Answer> findAnswerByQuestion_id(Integer question_id) {
		List<Answer> aList=answerRepository.findAnswersByQuestionID(question_id);
		return aList;
	}


	@Override
	public Answer findCorrectAnswerByQuestionID(Integer question_id) {
		List<Answer> answer=answerRepository.findCorrectAnswerByQuestionID(question_id);
		if(answer.isEmpty()) {
			return null;
		}
		return answer.get(0);
	}
	
	public List<String> getAnswersOfQuestion(Integer question_id){
		List<Answer> answer=answerRepository.findAnswersByQuestionID(question_id);
		if(answer.isEmpty()) {
			return null;
		}else {
			List<String> answerList=new ArrayList<String>();
			for(int i=0;i<answer.size();i++) {
				answerList.add(answer.get(i).getAnswer());
			}
			return answerList;
		}
	}
	
	public QuizCategory findQuizCategory(Integer id) {
		List<QuizCategory> quizCategory=quizCategoryRepository.findByQuiz_category_id(id);
		if(!quizCategory.isEmpty()) {
			return quizCategory.get(0);
		}else {
			return null;
		}
		
	}

}
