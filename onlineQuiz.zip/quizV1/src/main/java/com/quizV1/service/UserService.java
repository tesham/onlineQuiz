package com.quizV1.service;

import com.quizV1.model.User;

public interface UserService {
	public void saveUser(User user);
	public boolean getUser(String userName);
}
