package com.quizV1.service;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.quizV1.model.Answer;
import com.quizV1.model.Question;
import com.quizV1.model.QuizCategory;
import com.quizV1.model.QuizTopic;

public interface QuizService {
	List<QuizCategory> findAll();
	List<QuizTopic> findAllTopic(Integer id);
	List<Question> findQuestionsByTopic(Integer topic_id);
	List<Answer> findAnswerByQuestion_id(Integer question_id);
	Answer findCorrectAnswerByQuestionID( Integer question_id);
}
