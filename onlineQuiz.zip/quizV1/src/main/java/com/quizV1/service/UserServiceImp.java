package com.quizV1.service;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Optional;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.mysql.jdbc.Connection;
import com.quizV1.model.Role;
import com.quizV1.model.User;
import com.quizV1.repository.RoleRepository;
import com.quizV1.repository.UserRepository;

@Service
public class UserServiceImp implements UserService {
	
//	@Autowired
//	private DataSource dataSource;
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	 private RoleRepository roleRespository;

	@Override
	public void saveUser(User user) {
		  // user.setPassword((user.getPassword()));
		  user.setActive(1);
		 // user.setName(user.getName());
		  Optional<Role> userRole = roleRespository.findById(1);
		//  Role userRole = roleRespository.findByRole("ADMIN");
		
		  user.setRoles(new HashSet<Role>(Arrays.asList(userRole.get())));
		  userRepository.save(user);
		
	}

	@Override
	public boolean getUser(String userName) {
		// TODO Auto-generated method stub
		Optional<User> user=userRepository.findByName(userName);
		if(user.isPresent()) {
			return true;
		}
		return false;
	}

	public boolean findByMail(String mail) {
		Optional<User> user=userRepository.findByEmail(mail);
		if(user.isPresent()) {
			return true;
		}
		return false;
	}
	

}
