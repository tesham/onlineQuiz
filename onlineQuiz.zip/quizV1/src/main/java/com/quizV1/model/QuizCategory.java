package com.quizV1.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "quiz_category")
public class QuizCategory {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "quiz_category_id")
    private int quiz_category_id;
	
	@Column(name = "quiz_category_name")
    private String quiz_category_name;

	public int getQuiz_category_id() {
		return quiz_category_id;
	}

	public void setQuiz_category_id(int quiz_category_id) {
		this.quiz_category_id = quiz_category_id;
	}

	public String getQuiz_category_name() {
		return quiz_category_name;
	}

	public void setQuiz_category_name(String quiz_category_name) {
		this.quiz_category_name = quiz_category_name;
	}
	
	
	
}
