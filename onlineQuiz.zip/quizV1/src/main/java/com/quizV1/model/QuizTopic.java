package com.quizV1.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "quiz_topic")
public class QuizTopic {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "topic_id")
    private int topic_id;
	
	@Column(name = "topic")
    private String topic;
	
	@Column(name = "quiz_category_id")
	private int quizCategory;

	public int getTopic_id() {
		return topic_id;
	}

	public void setTopic_id(int topic_id) {
		this.topic_id = topic_id;
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public int getQuizCategory() {
		return quizCategory;
	}

	public void setQuizCategory(int quizCategory) {
		this.quizCategory = quizCategory;
	}
	
}
