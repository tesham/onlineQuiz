package com.quizV1.model;


import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name = "user")
public class User {
	 @Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	 @Column(name = "user_id")
	 private int id;
	 
	 @Column(name = "email")
	 private String email;
	 
	 @Column(name = "password")
	 private String password;
	 
	 @Column(name = "name")
	 private String name; 
	 
	 @Column(name = "active")
	 private int active;
	 
	 @ManyToMany(cascade=CascadeType.ALL,fetch = FetchType.EAGER)
	 @JoinTable(name="user_role", joinColumns=@JoinColumn(name="user_id"), inverseJoinColumns=@JoinColumn(name="role_id"))
	 private Set<Role> roles;
	 
//	 @ManyToMany(cascade=CascadeType.ALL)
//	 @JoinTable(name="user_role", joinColumns=@JoinColumn(name="user_id"), inverseJoinColumns=@JoinColumn(name="role_id"))
//	  @ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
//	  @JoinTable(name = "user_role", joinColumns = @JoinColumn(name = "user_id"), inverseJoinColumns = @JoinColumn(name = "role_id"))
//	   private Set<Role> roles;
	  
	  public User() {
	    }

	    public User(User user) {
	        this.active = user.getActive();
	        this.email = user.getEmail();
	        this.roles = user.getRoles();
	        this.name = user.getName();
	        this.id = user.getId();
	        this.password = user.getPassword();
	    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	public Set<Role> getRoles() {
		return roles;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}
  
}
